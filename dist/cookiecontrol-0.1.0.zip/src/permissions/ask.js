import { permissionsRequest } from '../utils/chrome.js';

function getParam(name) {
  const url = new URL(window.location.href);
  return url.searchParams.get(name);
}

function setStatus(text, cls) {
  const el = document.getElementById('status');
  if (!el) return;
  el.textContent = text || '';
  el.className = cls || '';
}

async function requestNow() {
  try {
    const raw = getParam('origins') || '';
    const origins = raw.split(',').map(s => decodeURIComponent(s.trim())).filter(Boolean);
    if (!origins.length) {
      setStatus('No origins provided.', 'err');
      return;
    }

    // Request (sanitizer will validate patterns)
    let granted = await permissionsRequest({ origins });
    if (!granted && origins.length > 1) {
      // Fallback: try sequentially per-origin to surface the prompt
      for (const o of origins) {
        const ok = await permissionsRequest({ origins: [o] });
        if (ok) granted = true;
      }
    }
    if (granted) {
      setStatus('Permission granted.', 'ok');
      // Try to auto-close this tab after a short delay
      setTimeout(() => {
        try {
          chrome.tabs.getCurrent((tab) => {
            if (tab && tab.id) chrome.tabs.remove(tab.id);
            else window.close();
          });
        } catch (_) {
          // ignore
        }
      }, 400);
    } else {
      setStatus('Permission not granted or was dismissed.', 'err');
    }
  } catch (e) {
    setStatus(`Error: ${e && e.message ? e.message : String(e)}`, 'err');
  }
}

// Require explicit user gesture in Firefox: bind to the button
document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('request-btn');
  const cancel = document.getElementById('cancel-btn');
  if (btn) btn.addEventListener('click', () => requestNow());
  if (cancel) cancel.addEventListener('click', () => window.close());
});
